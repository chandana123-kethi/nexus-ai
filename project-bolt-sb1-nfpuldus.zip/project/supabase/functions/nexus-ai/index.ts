// NEXUS AI Edge Function
// Handles: chat streaming (SSE), prompt enhancement, conversation insights, message feedback.
// OpenAI API key is read from the OPENAI_API_KEY secret (set via Bolt/Supabase Secrets).

import { createClient } from "npm:@supabase/supabase-js@2.57.4";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info, Apikey",
};

const OPENAI_API_KEY = Deno.env.get("OPENAI_API_KEY") ?? "";
const OPENAI_CHAT_URL = "https://api.openai.com/v1/chat/completions";
const MODEL = "gpt-4o-mini";

const SUPABASE_URL = Deno.env.get("SUPABASE_URL") ?? Deno.env.get("VITE_SUPABASE_URL") ?? "";
const SERVICE_ROLE_KEY = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") ?? "";

function jsonResponse(body: unknown, status = 200, extra: Record<string, string> = {}) {
  return new Response(JSON.stringify(body), {
    status,
    headers: { ...corsHeaders, "Content-Type": "application/json", ...extra },
  });
}

function errorResponse(message: string, status = 500) {
  return jsonResponse({ error: message }, status);
}

const TONE_INSTRUCTIONS: Record<string, string> = {
  professional:
    "Respond in a professional, formal, structured and business-oriented tone. Use clear headings and organized reasoning where helpful.",
  casual:
    "Respond in a friendly, natural and conversational tone. Be warm and approachable, like talking to a knowledgeable friend.",
  concise:
    "Respond concisely. Keep answers short, direct and easy to understand. Avoid unnecessary elaboration. Prefer bullet points when listing.",
};

interface ChatMessage {
  role: "system" | "user" | "assistant";
  content: string;
}

interface ConversationRow {
  id: string;
  title: string;
  selected_tone: string;
}

interface MessageRow {
  id: string;
  role: string;
  content: string;
  tone: string | null;
  feedback: string | null;
  created_at: string;
}

function getSupabaseAdmin() {
  if (!SUPABASE_URL || !SERVICE_ROLE_KEY) {
    throw new Error("Server is missing Supabase configuration.");
  }
  return createClient(SUPABASE_URL, SERVICE_ROLE_KEY, {
    auth: { persistSession: false },
  });
}

async function fetchMessages(conversationId: string): Promise<MessageRow[]> {
  const supabase = getSupabaseAdmin();
  const { data, error } = await supabase
    .from("messages")
    .select("id, role, content, tone, feedback, created_at")
    .eq("conversation_id", conversationId)
    .order("created_at", { ascending: true });
  if (error) throw new Error(`Failed to load messages: ${error.message}`);
  return (data ?? []) as MessageRow[];
}

async function insertMessage(
  conversationId: string,
  role: string,
  content: string,
  tone: string | null,
): Promise<string> {
  const supabase = getSupabaseAdmin();
  const { data, error } = await supabase
    .from("messages")
    .insert({ conversation_id: conversationId, role, content, tone })
    .select("id")
    .single();
  if (error) throw new Error(`Failed to save ${role} message: ${error.message}`);
  return data.id as string;
}

async function touchConversation(conversationId: string) {
  const supabase = getSupabaseAdmin();
  await supabase
    .from("conversations")
    .update({ updated_at: new Date().toISOString() })
    .eq("id", conversationId);
}

async function maybeSetTitle(conversationId: string, firstUserText: string) {
  const supabase = getSupabaseAdmin();
  const { data: conv } = await supabase
    .from("conversations")
    .select("title, selected_tone")
    .eq("id", conversationId)
    .maybeSingle();
  if (!conv) return;
  if (conv.title && conv.title !== "New Chat") return;
  const title = firstUserText.trim().slice(0, 60) || "New Chat";
  await supabase.from("conversations").update({ title }).eq("id", conversationId);
}

async function callOpenAI(
  messages: ChatMessage[],
  opts: { stream?: boolean; temperature?: number; max_tokens?: number } = {},
): Promise<Response> {
  if (!OPENAI_API_KEY) {
    throw new Error("OpenAI API key is not configured. Add OPENAI_API_KEY in Secrets.");
  }
  const res = await fetch(OPENAI_CHAT_URL, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Authorization: `Bearer ${OPENAI_API_KEY}`,
    },
    body: JSON.stringify({
      model: MODEL,
      messages,
      stream: opts.stream ?? false,
      temperature: opts.temperature ?? 0.7,
      max_tokens: opts.max_tokens,
    }),
  });
  if (!res.ok) {
    let detail = "";
    try {
      const j = await res.json();
      detail = j?.error?.message ?? "";
    } catch {
      /* ignore */
    }
    if (res.status === 429) {
      throw new Error("OpenAI rate limit reached. Please try again shortly.");
    }
    throw new Error(`OpenAI request failed (${res.status}). ${detail}`.trim());
  }
  return res;
}

function buildContextMessages(
  history: MessageRow[],
  tone: string,
  extraSystem?: string,
): ChatMessage[] {
  const toneInstruction =
    TONE_INSTRUCTIONS[tone] ?? TONE_INSTRUCTIONS.professional;
  const system: ChatMessage = {
    role: "system",
    content:
      `You are NEXUS AI, an intelligent conversational workspace assistant. ` +
      `Tagline: "Think Better. Create Faster." ` +
      `${toneInstruction} ` +
      `Format answers with Markdown. Use code blocks with language labels for code. ` +
      `${extraSystem ?? ""}`.trim(),
  };
  const msgs: ChatMessage[] = [system];
  for (const m of history) {
    if (m.role === "system") continue;
    msgs.push({ role: m.role as "user" | "assistant", content: m.content });
  }
  return msgs;
}

// ---------- Route handlers ----------

async function handleStreamChat(req: Request): Promise<Response> {
  let body: {
    conversationId?: string;
    message?: string;
    tone?: string;
  } = {};
  try {
    body = await req.json();
  } catch {
    return errorResponse("Invalid JSON body.", 400);
  }
  const conversationId = body.conversationId?.trim();
  const userText = body.message?.trim() ?? "";
  const tone = body.tone ?? "professional";
  if (!conversationId) return errorResponse("conversationId is required.", 400);
  if (!userText) return errorResponse("message is required.", 400);

  // Save the user message
  await insertMessage(conversationId, "user", userText, null);
  await maybeSetTitle(conversationId, userText);
  await touchConversation(conversationId);

  const history = await fetchMessages(conversationId);
  const context = buildContextMessages(history, tone);

  let upstream: Response;
  try {
    upstream = await callOpenAI(context, { stream: true, max_tokens: 1200 });
  } catch (e) {
    return errorResponse(e instanceof Error ? e.message : "AI request failed.", 502);
  }

  // We stream the upstream SSE to the client while accumulating the full text,
  // then persist the assistant message after the stream closes.
  const encoder = new TextEncoder();
  const decoder = new TextDecoder();
  const reader = upstream.body?.getReader();
  if (!reader) return errorResponse("Streaming unavailable.", 500);

  let buffer = "";
  let fullText = "";

  const stream = new ReadableStream<Uint8Array>({
    async start(controller) {
      try {
        while (true) {
          const { done, value } = await reader.read();
          if (done) break;
          buffer += decoder.decode(value, { stream: true });
          const lines = buffer.split("\n");
          buffer = lines.pop() ?? "";
          for (const line of lines) {
            const trimmed = line.trim();
            if (!trimmed.startsWith("data:")) continue;
            const payload = trimmed.slice(5).trim();
            if (payload === "[DONE]") {
              controller.enqueue(encoder.encode("data: [DONE]\n\n"));
              continue;
            }
            try {
              const json = JSON.parse(payload);
              const delta: string = json?.choices?.[0]?.delta?.content ?? "";
              if (delta) {
                fullText += delta;
                controller.enqueue(
                  encoder.encode(`data: ${JSON.stringify({ delta })}\n\n`),
                );
              }
            } catch {
              // ignore malformed keep-alive lines
            }
          }
        }
      } catch (err) {
        controller.enqueue(
          encoder.encode(
            `data: ${JSON.stringify({ error: err instanceof Error ? err.message : "stream error" })}\n\n`,
          ),
        );
      } finally {
        try {
          controller.close();
        } catch {
          /* already closed */
        }
        // Persist assistant message after stream completes
        if (fullText.trim()) {
          try {
            await insertMessage(conversationId, "assistant", fullText, tone);
            await touchConversation(conversationId);
          } catch {
            // persistence failure is non-fatal to the client
          }
        }
      }
    },
    cancel() {
      reader.cancel().catch(() => {});
    },
  });

  return new Response(stream, {
    status: 200,
    headers: {
      ...corsHeaders,
      "Content-Type": "text/event-stream",
      "Cache-Control": "no-cache, no-transform",
      Connection: "keep-alive",
      "X-Accel-Buffering": "no",
    },
  });
}

async function handleEnhancePrompt(req: Request): Promise<Response> {
  let body: { prompt?: string; tone?: string } = {};
  try {
    body = await req.json();
  } catch {
    return errorResponse("Invalid JSON body.", 400);
  }
  const prompt = body.prompt?.trim() ?? "";
  if (!prompt) return errorResponse("prompt is required.", 400);
  const tone = body.tone ?? "professional";

  const messages: ChatMessage[] = [
    {
      role: "system",
      content:
        `You are a prompt engineering expert. Rewrite the user's prompt to improve clarity, ` +
        `add useful context, and structure it for a high-quality AI response. ` +
        `Do not answer the prompt itself. Output ONLY the improved prompt text, no preamble. ` +
        `Match a ${tone} tone in the improved prompt.`,
    },
    { role: "user", content: prompt },
  ];

  try {
    const res = await callOpenAI(messages, { temperature: 0.4, max_tokens: 400 });
    const data = await res.json();
    const improved: string = data?.choices?.[0]?.message?.content?.trim() ?? "";
    if (!improved) return errorResponse("Could not enhance prompt.", 502);
    return jsonResponse({ original: prompt, enhanced: improved });
  } catch (e) {
    return errorResponse(e instanceof Error ? e.message : "Enhance failed.", 502);
  }
}

async function handleInsights(req: Request): Promise<Response> {
  let body: { conversationId?: string } = {};
  try {
    body = await req.json();
  } catch {
    return errorResponse("Invalid JSON body.", 400);
  }
  const conversationId = body.conversationId?.trim();
  if (!conversationId) return errorResponse("conversationId is required.", 400);

  const history = await fetchMessages(conversationId);
  const dialog = history
    .filter((m) => m.role !== "system")
    .map((m) => `${m.role.toUpperCase()}: ${m.content}`)
    .join("\n\n");

  if (!dialog.trim()) {
    return jsonResponse({
      summary: "",
      key_takeaways: [],
      decisions: [],
      action_items: [],
      empty: true,
    });
  }

  const sys: ChatMessage = {
    role: "system",
    content:
      `You are a conversation intelligence engine. Analyze the conversation and return ONLY ` +
      `valid JSON (no markdown, no code fences) with this exact shape:\n` +
      `{\n` +
      `  "summary": string,\n` +
      `  "key_takeaways": string[],\n` +
      `  "decisions": string[],\n` +
      `  "action_items": string[]\n` +
      `}\n` +
      `Rules:\n` +
      `- "summary": a concise overview of the discussion (2-3 sentences).\n` +
      `- "key_takeaways": the most important information points.\n` +
      `- "decisions": only explicit decisions or conclusions actually reached. If none, use [].\n` +
      `- "action_items": concrete next steps or tasks identified. If none, use [].\n` +
      `- NEVER invent decisions or action items not supported by the conversation.\n` +
      `- If the conversation is too short to yield an insight, return empty arrays.`,
  };
  const userMsg: ChatMessage = { role: "user", content: dialog };

  try {
    const res = await callOpenAI([sys, userMsg], { temperature: 0.2, max_tokens: 800 });
    const data = await res.json();
    let raw: string = data?.choices?.[0]?.message?.content?.trim() ?? "";
    // strip accidental code fences
    raw = raw.replace(/^```(?:json)?\s*/i, "").replace(/\s*```$/i, "");
    let parsed: {
      summary?: string;
      key_takeaways?: string[];
      decisions?: string[];
      action_items?: string[];
    };
    try {
      parsed = JSON.parse(raw);
    } catch {
      return errorResponse("Insights parse failed.", 502);
    }

    const summary = String(parsed.summary ?? "");
    const key_takeaways = Array.isArray(parsed.key_takeaways)
      ? parsed.key_takeaways.map(String)
      : [];
    const decisions = Array.isArray(parsed.decisions)
      ? parsed.decisions.map(String)
      : [];
    const action_items = Array.isArray(parsed.action_items)
      ? parsed.action_items.map(String)
      : [];

    // Persist (upsert) into insights table
    const supabase = getSupabaseAdmin();
    await supabase
      .from("insights")
      .upsert(
        {
          conversation_id: conversationId,
          summary,
          key_takeaways,
          decisions,
          action_items,
          updated_at: new Date().toISOString(),
        },
        { onConflict: "conversation_id" },
      );

    return jsonResponse({
      summary,
      key_takeaways,
      decisions,
      action_items,
      empty: false,
    });
  } catch (e) {
    return errorResponse(e instanceof Error ? e.message : "Insights failed.", 502);
  }
}

async function handleFeedback(req: Request): Promise<Response> {
  let body: { messageId?: string; feedback?: string } = {};
  try {
    body = await req.json();
  } catch {
    return errorResponse("Invalid JSON body.", 400);
  }
  const messageId = body.messageId?.trim();
  const feedback = body.feedback;
  if (!messageId) return errorResponse("messageId is required.", 400);
  if (feedback !== "like" && feedback !== "dislike") {
    return errorResponse("feedback must be 'like' or 'dislike'.", 400);
  }
  const supabase = getSupabaseAdmin();
  const { error } = await supabase
    .from("messages")
    .update({ feedback })
    .eq("id", messageId);
  if (error) return errorResponse(error.message, 500);
  return jsonResponse({ ok: true });
}

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { status: 200, headers: corsHeaders });
  }
  if (req.method !== "POST") {
    return errorResponse("Method not allowed.", 405);
  }

  const url = new URL(req.url);
  const action = url.searchParams.get("action") ?? "stream";

  try {
    switch (action) {
      case "stream":
        return await handleStreamChat(req);
      case "enhance":
        return await handleEnhancePrompt(req);
      case "insights":
        return await handleInsights(req);
      case "feedback":
        return await handleFeedback(req);
      default:
        return errorResponse(`Unknown action: ${action}`, 404);
    }
  } catch (e) {
    return errorResponse(e instanceof Error ? e.message : "Unexpected error.", 500);
  }
});

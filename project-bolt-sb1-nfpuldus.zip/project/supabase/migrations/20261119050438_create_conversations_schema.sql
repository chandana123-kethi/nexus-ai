/*
# NEXUS AI - Conversations schema (single-tenant, no auth)

## Purpose
Stores conversation history, messages, tone, and AI-generated insights for the NEXUS AI chat assistant.

## New Tables
1. `conversations`
   - `id` (uuid, PK)
   - `title` (text, default 'New Chat')
   - `selected_tone` (text, default 'professional'; one of professional|casual|concise)
   - `created_at` (timestamptz)
   - `updated_at` (timestamptz)

2. `messages`
   - `id` (uuid, PK)
   - `conversation_id` (uuid, FK -> conversations.id ON DELETE CASCADE)
   - `role` (text: user|assistant|system)
   - `content` (text)
   - `tone` (text, nullable)
   - `feedback` (text, nullable: like|dislike)
   - `created_at` (timestamptz)

3. `insights`
   - `id` (uuid, PK)
   - `conversation_id` (uuid, FK -> conversations.id ON DELETE CASCADE, unique)
   - `summary` (text)
   - `key_takeaways` (jsonb, default '[]')
   - `decisions` (jsonb, default '[]')
   - `action_items` (jsonb, default '[]')
   - `created_at` (timestamptz)
   - `updated_at` (timestamptz)

## Security
- Single-tenant app (no sign-in screen). RLS enabled on all tables.
- Grants CRUD to `anon, authenticated` so the anon-key frontend can operate.
- Policies use `USING (true)` / `WITH CHECK (true)` because data is intentionally shared (no per-user isolation).
- `service_role` granted for edge function server-side writes.

## Notes
- Cascading deletes: removing a conversation removes its messages and insights.
- `insights.conversation_id` has a unique constraint so each conversation has at most one insight row (upserted on refresh).
*/

CREATE TABLE IF NOT EXISTS conversations (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  title text NOT NULL DEFAULT 'New Chat',
  selected_tone text NOT NULL DEFAULT 'professional',
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE conversations ENABLE ROW LEVEL SECURITY;

GRANT SELECT, INSERT, UPDATE, DELETE ON conversations TO anon, authenticated;
GRANT SELECT, INSERT, UPDATE, DELETE ON conversations TO service_role;

DROP POLICY IF EXISTS "anon_select_conversations" ON conversations;
CREATE POLICY "anon_select_conversations" ON conversations FOR SELECT
  TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "anon_insert_conversations" ON conversations;
CREATE POLICY "anon_insert_conversations" ON conversations FOR INSERT
  TO anon, authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "anon_update_conversations" ON conversations;
CREATE POLICY "anon_update_conversations" ON conversations FOR UPDATE
  TO anon, authenticated USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "anon_delete_conversations" ON conversations;
CREATE POLICY "anon_delete_conversations" ON conversations FOR DELETE
  TO anon, authenticated USING (true);

CREATE TABLE IF NOT EXISTS messages (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  conversation_id uuid NOT NULL REFERENCES conversations(id) ON DELETE CASCADE,
  role text NOT NULL CHECK (role IN ('user','assistant','system')),
  content text NOT NULL DEFAULT '',
  tone text,
  feedback text CHECK (feedback IN ('like','dislike') OR feedback IS NULL),
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_messages_conversation_id ON messages(conversation_id);

ALTER TABLE messages ENABLE ROW LEVEL SECURITY;

GRANT SELECT, INSERT, UPDATE, DELETE ON messages TO anon, authenticated;
GRANT SELECT, INSERT, UPDATE, DELETE ON messages TO service_role;

DROP POLICY IF EXISTS "anon_select_messages" ON messages;
CREATE POLICY "anon_select_messages" ON messages FOR SELECT
  TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "anon_insert_messages" ON messages;
CREATE POLICY "anon_insert_messages" ON messages FOR INSERT
  TO anon, authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "anon_update_messages" ON messages;
CREATE POLICY "anon_update_messages" ON messages FOR UPDATE
  TO anon, authenticated USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "anon_delete_messages" ON messages;
CREATE POLICY "anon_delete_messages" ON messages FOR DELETE
  TO anon, authenticated USING (true);

CREATE TABLE IF NOT EXISTS insights (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  conversation_id uuid NOT NULL UNIQUE REFERENCES conversations(id) ON DELETE CASCADE,
  summary text NOT NULL DEFAULT '',
  key_takeaways jsonb NOT NULL DEFAULT '[]'::jsonb,
  decisions jsonb NOT NULL DEFAULT '[]'::jsonb,
  action_items jsonb NOT NULL DEFAULT '[]'::jsonb,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE insights ENABLE ROW LEVEL SECURITY;

GRANT SELECT, INSERT, UPDATE, DELETE ON insights TO anon, authenticated;
GRANT SELECT, INSERT, UPDATE, DELETE ON insights TO service_role;

DROP POLICY IF EXISTS "anon_select_insights" ON insights;
CREATE POLICY "anon_select_insights" ON insights FOR SELECT
  TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "anon_insert_insights" ON insights;
CREATE POLICY "anon_insert_insights" ON insights FOR INSERT
  TO anon, authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "anon_update_insights" ON insights;
CREATE POLICY "anon_update_insights" ON insights FOR UPDATE
  TO anon, authenticated USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "anon_delete_insights" ON insights;
CREATE POLICY "anon_delete_insights" ON insights FOR DELETE
  TO anon, authenticated USING (true);

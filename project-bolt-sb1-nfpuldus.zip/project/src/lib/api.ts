import { EDGE_FUNCTION_URL } from './supabase';
import type { Conversation, EnhanceResult, Insights, Tone } from '@/types';

const headers = () => ({
  'Content-Type': 'application/json',
  apikey: import.meta.env.VITE_SUPABASE_ANON_KEY as string,
  Authorization: `Bearer ${import.meta.env.VITE_SUPABASE_ANON_KEY as string}`,
});

// ---------- Conversations (Data API) ----------

export async function fetchConversations(): Promise<Conversation[]> {
  const res = await fetch(
    `${import.meta.env.VITE_SUPABASE_URL}/rest/v1/conversations?select=id,title,selected_tone,created_at,updated_at&order=updated_at.desc`,
    { headers: headers() },
  );
  if (!res.ok) throw new Error('Failed to load conversations.');
  const rows = await res.json();
  return (rows as Array<Record<string, unknown>>).map((r) => ({
    id: r.id as string,
    title: r.title as string,
    selectedTone: r.selected_tone as Tone,
    createdAt: r.created_at as string,
    updatedAt: r.updated_at as string,
  }));
}

export async function fetchMessages(conversationId: string) {
  const res = await fetch(
    `${import.meta.env.VITE_SUPABASE_URL}/rest/v1/messages?select=id,conversation_id,role,content,tone,feedback,created_at&conversation_id=eq.${conversationId}&order=created_at.asc`,
    { headers: headers() },
  );
  if (!res.ok) throw new Error('Failed to load messages.');
  const rows = await res.json();
  return (rows as Array<Record<string, unknown>>).map((r) => ({
    id: r.id as string,
    conversationId: r.conversation_id as string,
    role: r.role as 'user' | 'assistant' | 'system',
    content: r.content as string,
    tone: (r.tone as Tone) ?? null,
    feedback: (r.feedback as 'like' | 'dislike') ?? null,
    createdAt: r.created_at as string,
  }));
}

export async function createConversation(title = 'New Chat', tone: Tone = 'professional'): Promise<Conversation> {
  const res = await fetch(
    `${import.meta.env.VITE_SUPABASE_URL}/rest/v1/conversations`,
    {
      method: 'POST',
      headers: { ...headers(), Prefer: 'return=representation' },
      body: JSON.stringify({ title, selected_tone: tone }),
    },
  );
  if (!res.ok) throw new Error('Failed to create conversation.');
  const rows = await res.json();
  const r = rows[0];
  return {
    id: r.id,
    title: r.title,
    selectedTone: r.selected_tone,
    createdAt: r.created_at,
    updatedAt: r.updated_at,
  };
}

export async function renameConversation(id: string, title: string): Promise<void> {
  const res = await fetch(
    `${import.meta.env.VITE_SUPABASE_URL}/rest/v1/conversations?id=eq.${id}`,
    {
      method: 'PATCH',
      headers: { ...headers(), Prefer: 'return=minimal' },
      body: JSON.stringify({ title }),
    },
  );
  if (!res.ok) throw new Error('Failed to rename conversation.');
}

export async function updateConversationTone(id: string, tone: Tone): Promise<void> {
  const res = await fetch(
    `${import.meta.env.VITE_SUPABASE_URL}/rest/v1/conversations?id=eq.${id}`,
    {
      method: 'PATCH',
      headers: { ...headers(), Prefer: 'return=minimal' },
      body: JSON.stringify({ selected_tone: tone }),
    },
  );
  if (!res.ok) throw new Error('Failed to update tone.');
}

export async function deleteConversation(id: string): Promise<void> {
  const res = await fetch(
    `${import.meta.env.VITE_SUPABASE_URL}/rest/v1/conversations?id=eq.${id}`,
    { method: 'DELETE', headers: { ...headers(), Prefer: 'return=minimal' } },
  );
  if (!res.ok) throw new Error('Failed to delete conversation.');
}

export async function fetchInsights(conversationId: string): Promise<Insights | null> {
  const res = await fetch(
    `${import.meta.env.VITE_SUPABASE_URL}/rest/v1/insights?select=summary,key_takeaways,decisions,action_items,updated_at&conversation_id=eq.${conversationId}`,
    { headers: headers() },
  );
  if (!res.ok) return null;
  const rows = await res.json();
  if (!rows.length) return null;
  const r = rows[0];
  return {
    conversationId,
    summary: r.summary ?? '',
    keyTakeaways: r.key_takeaways ?? [],
    decisions: r.decisions ?? [],
    actionItems: r.action_items ?? [],
    updatedAt: r.updated_at,
  };
}

// ---------- Edge function actions ----------

export interface StreamCallbacks {
  onDelta: (text: string) => void;
  onError: (message: string) => void;
  onDone: () => void;
}

export function streamChat(
  conversationId: string,
  message: string,
  tone: Tone,
  callbacks: StreamCallbacks,
  signal?: AbortSignal,
): void {
  (async () => {
    try {
      const res = await fetch(`${EDGE_FUNCTION_URL}?action=stream`, {
        method: 'POST',
        headers: headers(),
        body: JSON.stringify({ conversationId, message, tone }),
        signal,
      });
      if (!res.ok) {
        const data = await res.json().catch(() => ({}));
        callbacks.onError(data?.error ?? `Request failed (${res.status}).`);
        return;
      }
      const reader = res.body?.getReader();
      if (!reader) {
        callbacks.onError('No response stream.');
        return;
      }
      const decoder = new TextDecoder();
      let buffer = '';
      while (true) {
        const { done, value } = await reader.read();
        if (done) break;
        buffer += decoder.decode(value, { stream: true });
        const lines = buffer.split('\n');
        buffer = lines.pop() ?? '';
        for (const line of lines) {
          const trimmed = line.trim();
          if (!trimmed.startsWith('data:')) continue;
          const payload = trimmed.slice(5).trim();
          if (payload === '[DONE]') {
            callbacks.onDone();
            return;
          }
          try {
            const json = JSON.parse(payload);
            if (json.error) {
              callbacks.onError(json.error);
              return;
            }
            if (json.delta) callbacks.onDelta(json.delta);
          } catch {
            /* keep-alive */
          }
        }
      }
      callbacks.onDone();
    } catch (e) {
      if (e instanceof DOMException && e.name === 'AbortError') {
        callbacks.onDone();
        return;
      }
      callbacks.onError(e instanceof Error ? e.message : 'Streaming failed.');
    }
  })();
}

export async function enhancePrompt(prompt: string, tone: Tone): Promise<EnhanceResult> {
  const res = await fetch(`${EDGE_FUNCTION_URL}?action=enhance`, {
    method: 'POST',
    headers: headers(),
    body: JSON.stringify({ prompt, tone }),
  });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(data?.error ?? 'Enhance failed.');
  return { original: data.original, enhanced: data.enhanced };
}

export async function generateInsights(conversationId: string): Promise<Insights> {
  const res = await fetch(`${EDGE_FUNCTION_URL}?action=insights`, {
    method: 'POST',
    headers: headers(),
    body: JSON.stringify({ conversationId }),
  });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(data?.error ?? 'Insights failed.');
  return {
    conversationId,
    summary: data.summary ?? '',
    keyTakeaways: data.key_takeaways ?? [],
    decisions: data.decisions ?? [],
    actionItems: data.action_items ?? [],
    empty: data.empty,
  };
}

export async function sendFeedback(messageId: string, feedback: 'like' | 'dislike'): Promise<void> {
  const res = await fetch(`${EDGE_FUNCTION_URL}?action=feedback`, {
    method: 'POST',
    headers: headers(),
    body: JSON.stringify({ messageId, feedback }),
  });
  if (!res.ok) {
    const data = await res.json().catch(() => ({}));
    throw new Error(data?.error ?? 'Feedback failed.');
  }
}


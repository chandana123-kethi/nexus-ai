import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useRef,
  useState,
  type ReactNode,
} from 'react';
import type { ChatMessage, Conversation, Insights, Tone } from '@/types';
import * as api from '@/lib/api';
import { useToast } from './ToastContext';

interface ChatContextValue {
  conversations: Conversation[];
  current: Conversation | null;
  messages: ChatMessage[];
  insights: Insights | null;
  insightsLoading: boolean;
  isStreaming: boolean;
  streamingText: string;
  loadingConversations: boolean;
  loadingMessages: boolean;
  selectConversation: (id: string) => void;
  newConversation: () => Promise<void>;
  renameConversation: (id: string, title: string) => Promise<void>;
  deleteConversation: (id: string) => Promise<void>;
  sendMessage: (text: string) => Promise<void>;
  stopGeneration: () => void;
  regenerate: () => Promise<void>;
  setTone: (tone: Tone) => Promise<void>;
  refreshInsights: () => Promise<void>;
  setFeedback: (messageId: string, feedback: 'like' | 'dislike') => Promise<void>;
}

const ChatContext = createContext<ChatContextValue | null>(null);

export function ChatProvider({ children }: { children: ReactNode }) {
  const { toast } = useToast();
  const [conversations, setConversations] = useState<Conversation[]>([]);
  const [current, setCurrent] = useState<Conversation | null>(null);
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [insights, setInsights] = useState<Insights | null>(null);
  const [insightsLoading, setInsightsLoading] = useState(false);
  const [isStreaming, setIsStreaming] = useState(false);
  const [streamingText, setStreamingText] = useState('');
  const [loadingConversations, setLoadingConversations] = useState(true);
  const [loadingMessages, setLoadingMessages] = useState(false);

  const abortRef = useRef<AbortController | null>(null);

  // Load conversation list on mount
  useEffect(() => {
    (async () => {
      setLoadingConversations(true);
      try {
        const list = await api.fetchConversations();
        setConversations(list);
      } catch (e) {
        toast(e instanceof Error ? e.message : 'Failed to load conversations.', 'error');
      } finally {
        setLoadingConversations(false);
      }
    })();
  }, [toast]);

  const refreshList = useCallback(async () => {
    try {
      const list = await api.fetchConversations();
      setConversations(list);
    } catch {
      /* ignore */
    }
  }, []);

  const loadInsights = useCallback(async (conversationId: string) => {
    try {
      const data = await api.fetchInsights(conversationId);
      setInsights(data ? { ...data, conversationId } : null);
    } catch {
      setInsights(null);
    }
  }, []);

  const selectConversation = useCallback(
    (id: string) => {
      if (isStreaming) return;
      const conv = conversations.find((c) => c.id === id) ?? null;
      setCurrent(conv);
      setMessages([]);
      setInsights(null);
      setLoadingMessages(true);
      (async () => {
        try {
          const msgs = await api.fetchMessages(id);
          setMessages(msgs);
        } catch (e) {
          toast(e instanceof Error ? e.message : 'Failed to load messages.', 'error');
        } finally {
          setLoadingMessages(false);
        }
        loadInsights(id);
      })();
    },
    [conversations, isStreaming, toast, loadInsights],
  );

  const newConversation = useCallback(async () => {
    if (isStreaming) return;
    try {
      const conv = await api.createConversation('New Chat', current?.selectedTone ?? 'professional');
      setConversations((c) => [conv, ...c]);
      setCurrent(conv);
      setMessages([]);
      setInsights(null);
    } catch (e) {
      toast(e instanceof Error ? e.message : 'Failed to create conversation.', 'error');
    }
  }, [isStreaming, current, toast]);

  const renameConversation = useCallback(
    async (id: string, title: string) => {
      try {
        await api.renameConversation(id, title);
        setConversations((c) => c.map((x) => (x.id === id ? { ...x, title } : x)));
        setCurrent((cur) => (cur && cur.id === id ? { ...cur, title } : cur));
      } catch (e) {
        toast(e instanceof Error ? e.message : 'Rename failed.', 'error');
      }
    },
    [toast],
  );

  const deleteConversation = useCallback(
    async (id: string) => {
      try {
        await api.deleteConversation(id);
        setConversations((c) => c.filter((x) => x.id !== id));
        if (current?.id === id) {
          setCurrent(null);
          setMessages([]);
          setInsights(null);
        }
        toast('Conversation deleted.', 'success');
      } catch (e) {
        toast(e instanceof Error ? e.message : 'Delete failed.', 'error');
      }
    },
    [current, toast],
  );

  const persistAssistant = useCallback(
    async (conversationId: string, text: string, tone: Tone) => {
      // The edge function already persists the assistant message. We refresh
      // messages from the DB to obtain the real id/createdAt.
      try {
        const msgs = await api.fetchMessages(conversationId);
        setMessages(msgs);
        await refreshList();
        void tone;
      } catch {
        /* ignore */
      }
    },
    [refreshList],
  );

  const sendMessage = useCallback(
    async (text: string) => {
      const trimmed = text.trim();
      if (!trimmed || isStreaming) return;
      let conv = current;
      if (!conv) {
        try {
          conv = await api.createConversation('New Chat', 'professional');
          setConversations((c) => [conv!, ...c]);
          setCurrent(conv);
        } catch {
          toast('Failed to start conversation.', 'error');
          return;
        }
      }
      const conversationId = conv.id;
      const tone = conv.selectedTone;

      // Optimistic user bubble
      const optimisticUser: ChatMessage = {
        id: `tmp-${Date.now()}`,
        conversationId,
        role: 'user',
        content: trimmed,
        tone: null,
        feedback: null,
        createdAt: new Date().toISOString(),
      };
      setMessages((m) => [...m, optimisticUser]);
      setStreamingText('');
      setIsStreaming(true);

      const controller = new AbortController();
      abortRef.current = controller;

      let accumulated = '';
      api.streamChat(
        conversationId,
        trimmed,
        tone,
        {
          onDelta: (delta) => {
            accumulated += delta;
            setStreamingText(accumulated);
          },
          onError: (msg) => {
            setIsStreaming(false);
            setStreamingText('');
            abortRef.current = null;
            toast(msg, 'error');
            // refresh to reflect server-persisted user message
            api.fetchMessages(conversationId).then(setMessages).catch(() => {});
            refreshList();
          },
          onDone: () => {
            setIsStreaming(false);
            setStreamingText('');
            abortRef.current = null;
            persistAssistant(conversationId, accumulated, tone);
            // Refresh insights in background if conversation has content
            loadInsights(conversationId);
          },
        },
        controller.signal,
      );
    },
    [current, isStreaming, toast, refreshList, persistAssistant, loadInsights],
  );

  const stopGeneration = useCallback(() => {
    abortRef.current?.abort();
    abortRef.current = null;
    setIsStreaming(false);
    if (streamingText) {
      // Keep partial text as an assistant message preview (not persisted server-side)
      setMessages((m) => [
        ...m,
        {
          id: `partial-${Date.now()}`,
          conversationId: current?.id ?? '',
          role: 'assistant',
          content: streamingText,
          tone: current?.selectedTone ?? null,
          feedback: null,
          createdAt: new Date().toISOString(),
        },
      ]);
      setStreamingText('');
    }
    // Refresh real messages
    if (current) {
      api.fetchMessages(current.id).then(setMessages).catch(() => {});
      refreshList();
    }
  }, [streamingText, current, refreshList]);

  const regenerate = useCallback(async () => {
    if (isStreaming || !current) return;
    // Find last user message
    const lastUser = [...messages].reverse().find((m) => m.role === 'user');
    if (!lastUser) {
      toast('Nothing to regenerate.', 'info');
      return;
    }
    // Remove trailing assistant message(s) after last user message (client-side)
    const lastUserIdx = messages.map((m) => m.role).lastIndexOf('user');
    const trimmedMessages = messages.slice(0, lastUserIdx + 1);
    setMessages(trimmedMessages);

    // Delete server-side trailing assistant message(s) after last user
    const trailing = messages.slice(lastUserIdx + 1).filter((m) => m.role === 'assistant' && !m.id.startsWith('tmp') && !m.id.startsWith('partial'));
    for (const t of trailing) {
      try {
        await fetch(`${import.meta.env.VITE_SUPABASE_URL}/rest/v1/messages?id=eq.${t.id}`, {
          method: 'DELETE',
          headers: {
            apikey: import.meta.env.VITE_SUPABASE_ANON_KEY as string,
            Authorization: `Bearer ${import.meta.env.VITE_SUPABASE_ANON_KEY as string}`,
            Prefer: 'return=minimal',
          },
        });
      } catch {
        /* ignore */
      }
    }

    // Re-stream using last user text. But the server appends a NEW user message on stream,
    // which would duplicate. Instead we delete the last user message server-side too and
    // re-send it.
    const lastUserMsg = messages[lastUserIdx];
    if (lastUserMsg && !lastUserMsg.id.startsWith('tmp')) {
      try {
        await fetch(`${import.meta.env.VITE_SUPABASE_URL}/rest/v1/messages?id=eq.${lastUserMsg.id}`, {
          method: 'DELETE',
          headers: {
            apikey: import.meta.env.VITE_SUPABASE_ANON_KEY as string,
            Authorization: `Bearer ${import.meta.env.VITE_SUPABASE_ANON_KEY as string}`,
            Prefer: 'return=minimal',
          },
        });
      } catch {
        /* ignore */
      }
    }

    setMessages((m) => m.slice(0, lastUserIdx));
    setStreamingText('');
    setIsStreaming(true);
    const controller = new AbortController();
    abortRef.current = controller;
    let accumulated = '';
    api.streamChat(
      current.id,
      lastUser.content,
      current.selectedTone,
      {
        onDelta: (d) => {
          accumulated += d;
          setStreamingText(accumulated);
        },
        onError: (msg) => {
          setIsStreaming(false);
          setStreamingText('');
          abortRef.current = null;
          toast(msg, 'error');
          api.fetchMessages(current.id).then(setMessages).catch(() => {});
        },
        onDone: () => {
          setIsStreaming(false);
          setStreamingText('');
          abortRef.current = null;
          persistAssistant(current.id, accumulated, current.selectedTone);
          loadInsights(current.id);
        },
      },
      controller.signal,
    );
  }, [isStreaming, current, messages, toast, persistAssistant, loadInsights]);

  const setTone = useCallback(
    async (tone: Tone) => {
      if (!current) {
        // set on a ephemeral default; create will pick it up via current?.selectedTone fallback
        setCurrent((c) => (c ? { ...c, selectedTone: tone } : c));
        return;
      }
      try {
        await api.updateConversationTone(current.id, tone);
        setCurrent({ ...current, selectedTone: tone });
        setConversations((c) => c.map((x) => (x.id === current.id ? { ...x, selectedTone: tone } : x)));
      } catch (e) {
        toast(e instanceof Error ? e.message : 'Tone update failed.', 'error');
      }
    },
    [current, toast],
  );

  const refreshInsights = useCallback(async () => {
    if (!current) return;
    setInsightsLoading(true);
    try {
      const data = await api.generateInsights(current.id);
      setInsights(data);
      if (data.empty) toast('Not enough conversation to generate insights yet.', 'info');
      else toast('Insights refreshed.', 'success');
    } catch (e) {
      toast(e instanceof Error ? e.message : 'Insights failed.', 'error');
    } finally {
      setInsightsLoading(false);
    }
  }, [current, toast]);

  const setFeedback = useCallback(
    async (messageId: string, feedback: 'like' | 'dislike') => {
      // Optimistic
      setMessages((m) =>
        m.map((msg) => (msg.id === messageId ? { ...msg, feedback } : msg)),
      );
      try {
        await api.sendFeedback(messageId, feedback);
      } catch (e) {
        toast(e instanceof Error ? e.message : 'Feedback failed.', 'error');
        setMessages((m) =>
          m.map((msg) => (msg.id === messageId ? { ...msg, feedback: null } : msg)),
        );
      }
    },
    [toast],
  );

  return (
    <ChatContext.Provider
      value={{
        conversations,
        current,
        messages,
        insights,
        insightsLoading,
        isStreaming,
        streamingText,
        loadingConversations,
        loadingMessages,
        selectConversation,
        newConversation,
        renameConversation,
        deleteConversation,
        sendMessage,
        stopGeneration,
        regenerate,
        setTone,
        refreshInsights,
        setFeedback,
      }}
    >
      {children}
    </ChatContext.Provider>
  );
}

export function useChat() {
  const ctx = useContext(ChatContext);
  if (!ctx) throw new Error('useChat must be used within ChatProvider');
  return ctx;
}

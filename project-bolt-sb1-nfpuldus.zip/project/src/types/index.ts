export type Tone = 'professional' | 'casual' | 'concise';

export type MessageRole = 'user' | 'assistant' | 'system';

export type Feedback = 'like' | 'dislike' | null;

export interface ChatMessage {
  id: string;
  conversationId: string;
  role: MessageRole;
  content: string;
  tone: Tone | null;
  feedback: Feedback;
  createdAt: string;
}

export interface Conversation {
  id: string;
  title: string;
  selectedTone: Tone;
  createdAt: string;
  updatedAt: string;
}

export interface Insights {
  conversationId: string;
  summary: string;
  keyTakeaways: string[];
  decisions: string[];
  actionItems: string[];
  empty?: boolean;
  updatedAt?: string;
}

export interface EnhanceResult {
  original: string;
  enhanced: string;
}

export type Theme = 'dark' | 'light';

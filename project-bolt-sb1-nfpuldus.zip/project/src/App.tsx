import { useEffect, useState } from 'react';
import { Menu, X } from 'lucide-react';
import { ToastProvider } from '@/context/ToastContext';
import { ChatProvider, useChat } from '@/context/ChatContext';
import { Sidebar } from '@/components/Sidebar';
import { ChatPanel } from '@/components/ChatPanel';
import { IntelligencePanel } from '@/components/IntelligencePanel';
import { useTheme } from '@/hooks/useTheme';

function Shell() {
  const { theme, toggle } = useTheme();
  const { sendMessage, current } = useChat();
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [panelOpen, setPanelOpen] = useState(false);

  // Keyboard shortcuts
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      const mod = e.metaKey || e.ctrlKey;
      if (mod && e.key === 'k') {
        e.preventDefault();
        setSidebarOpen((o) => !o);
      }
      if (mod && e.key === 'i') {
        e.preventDefault();
        setPanelOpen((o) => !o);
      }
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, []);

  const handlePick = (prompt: string) => {
    if (current) sendMessage(prompt);
    else {
      // no current conversation: sendMessage creates one
      sendMessage(prompt);
    }
  };

  return (
    <div className={`h-screen w-screen overflow-hidden flex ${theme === 'dark' ? 'bg-nexus-bg text-slate-100' : 'bg-slate-100 text-slate-900'}`}>
      {/* Desktop sidebar */}
      <div className="hidden lg:block w-72 flex-shrink-0">
        <Sidebar theme={theme} onToggleTheme={toggle} />
      </div>

      {/* Mobile sidebar drawer */}
      {sidebarOpen && (
        <div className="lg:hidden fixed inset-0 z-40 flex">
          <div className="absolute inset-0 bg-black/60 backdrop-blur-sm" onClick={() => setSidebarOpen(false)} />
          <div className="relative w-72 max-w-[80vw] animate-slide-in-right">
            <Sidebar theme={theme} onToggleTheme={toggle} onClose={() => setSidebarOpen(false)} />
          </div>
        </div>
      )}

      {/* Center chat */}
      <div className="flex-1 flex flex-col min-w-0 relative">
        {/* mobile top bar */}
        <div className="lg:hidden flex items-center justify-between px-3 py-2 bg-nexus-surface border-b border-nexus-border">
          <button onClick={() => setSidebarOpen(true)} className="p-2 rounded-lg text-slate-300 hover:bg-white/5">
            <Menu className="w-5 h-5" />
          </button>
          <span className="font-display font-semibold text-sm gradient-text">NEXUS AI</span>
          <button onClick={() => setPanelOpen(true)} className="p-2 rounded-lg text-slate-300 hover:bg-white/5">
            <X className="w-5 h-5 rotate-45" />
          </button>
        </div>
        <div className="flex-1 min-h-0">
          <ChatPanel onPickWelcome={handlePick} />
        </div>
      </div>

      {/* Desktop intelligence panel */}
      <div className="hidden md:block w-80 flex-shrink-0">
        <IntelligencePanel />
      </div>

      {/* Mobile intelligence drawer */}
      {panelOpen && (
        <div className="md:hidden fixed inset-0 z-40 flex justify-end">
          <div className="absolute inset-0 bg-black/60 backdrop-blur-sm" onClick={() => setPanelOpen(false)} />
          <div className="relative w-80 max-w-[85vw] animate-slide-in-right">
            <IntelligencePanel onClose={() => setPanelOpen(false)} />
          </div>
        </div>
      )}
    </div>
  );
}

export default function App() {
  return (
    <ToastProvider>
      <ChatProvider>
        <Shell />
      </ChatProvider>
    </ToastProvider>
  );
}

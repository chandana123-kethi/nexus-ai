import { useState } from 'react';
import {
  PanelRightClose, PanelRightOpen, RefreshCw, FileText, Lightbulb,
  CheckCircle2, ListTodo, Loader2, Sparkles,
} from 'lucide-react';
import { useChat } from '@/context/ChatContext';

export function IntelligencePanel({ onClose }: { onClose?: () => void }) {
  const { insights, insightsLoading, refreshInsights, current, messages } = useChat();
  const [collapsed, setCollapsed] = useState(false);

  if (collapsed) {
    return (
      <div className="hidden md:flex flex-col items-center pt-4 bg-nexus-surface border-l border-nexus-border">
        <button
          onClick={() => setCollapsed(false)}
          className="p-2 rounded-lg text-slate-400 hover:text-white hover:bg-white/5 transition"
          title="Expand panel"
        >
          <PanelRightOpen className="w-5 h-5" />
        </button>
      </div>
    );
  }

  const hasMessages = messages.length > 0;
  const empty = !insights || (insights.empty ?? false) ||
    (!insights.summary && insights.keyTakeaways.length === 0 &&
     insights.decisions.length === 0 && insights.actionItems.length === 0);

  return (
    <div className="flex flex-col h-full bg-nexus-surface border-l border-nexus-border">
      <div className="flex items-center justify-between px-4 py-3 border-b border-nexus-border">
        <div className="flex items-center gap-2">
          <Sparkles className="w-4 h-4 text-nexus-accent" />
          <h3 className="font-display font-semibold text-sm text-slate-100">Intelligence</h3>
        </div>
        <div className="flex items-center gap-1">
          <button
            onClick={refreshInsights}
            disabled={insightsLoading || !current || !hasMessages}
            className="p-1.5 rounded-lg text-slate-400 hover:text-nexus-cyan disabled:opacity-30 transition"
            title="Refresh insights"
          >
            {insightsLoading ? <Loader2 className="w-4 h-4 animate-spin" /> : <RefreshCw className="w-4 h-4" />}
          </button>
          <button
            onClick={() => { setCollapsed(true); onClose?.(); }}
            className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-white/5 transition"
            title="Collapse"
          >
            <PanelRightClose className="w-5 h-5" />
          </button>
        </div>
      </div>

      <div className="flex-1 overflow-y-auto scrollbar-thin p-4 space-y-4">
        {!current && (
          <EmptyState text="Select or start a conversation to see insights." />
        )}
        {current && !hasMessages && (
          <EmptyState text="Start chatting to generate conversation insights." />
        )}
        {current && hasMessages && insightsLoading && (
          <div className="space-y-3">
            {[0, 1, 2].map((i) => <div key={i} className="skeleton h-24 w-full" />)}
          </div>
        )}
        {current && hasMessages && !insightsLoading && empty && (
          <EmptyState text="Not enough conversation yet to generate insights. Click refresh after a few messages." />
        )}
        {current && hasMessages && !insightsLoading && !empty && insights && (
          <>
            <InsightCard icon={FileText} title="Summary" accent="primary">
              <p className="text-sm text-slate-300 leading-relaxed">{insights.summary}</p>
            </InsightCard>
            <InsightList icon={Lightbulb} title="Key Takeaways" items={insights.keyTakeaways} accent="cyan" emptyText="No takeaways identified." />
            <InsightList icon={CheckCircle2} title="Decisions" items={insights.decisions} accent="emerald" emptyText="No explicit decisions yet." />
            <InsightList icon={ListTodo} title="Action Items" items={insights.actionItems} accent="accent" emptyText="No action items identified." />
          </>
        )}
      </div>
    </div>
  );
}

function EmptyState({ text }: { text: string }) {
  return (
    <div className="text-center py-10 px-4">
      <Sparkles className="w-8 h-8 mx-auto mb-3 text-slate-600" />
      <p className="text-sm text-slate-500">{text}</p>
    </div>
  );
}

function InsightCard({
  icon: Icon, title, accent, children,
}: {
  icon: typeof FileText; title: string; accent: string; children: React.ReactNode;
}) {
  const colors: Record<string, string> = {
    primary: 'from-nexus-primary/20 to-nexus-primary/5 border-nexus-primary/30 text-nexus-primary',
    cyan: 'from-nexus-cyan/20 to-nexus-cyan/5 border-nexus-cyan/30 text-nexus-cyan',
    emerald: 'from-emerald-500/20 to-emerald-500/5 border-emerald-500/30 text-emerald-400',
    accent: 'from-nexus-accent/20 to-nexus-accent/5 border-nexus-accent/30 text-nexus-accent',
  };
  return (
    <div className={`rounded-xl border bg-gradient-to-br p-4 ${colors[accent]}`}>
      <div className="flex items-center gap-2 mb-2">
        <Icon className="w-4 h-4" />
        <h4 className="font-display font-semibold text-sm text-slate-100">{title}</h4>
      </div>
      {children}
    </div>
  );
}

function InsightList({
  icon: Icon, title, items, accent, emptyText,
}: {
  icon: typeof FileText; title: string; items: string[]; accent: string; emptyText: string;
}) {
  return (
    <InsightCard icon={Icon} title={title} accent={accent}>
      {items.length === 0 ? (
        <p className="text-xs text-slate-500 italic">{emptyText}</p>
      ) : (
        <ul className="space-y-1.5">
          {items.map((item, i) => (
            <li key={i} className="flex items-start gap-2 text-sm text-slate-300">
              <span className="mt-1.5 w-1.5 h-1.5 rounded-full bg-current flex-shrink-0 opacity-60" />
              <span className="leading-relaxed">{item}</span>
            </li>
          ))}
        </ul>
      )}
    </InsightCard>
  );
}

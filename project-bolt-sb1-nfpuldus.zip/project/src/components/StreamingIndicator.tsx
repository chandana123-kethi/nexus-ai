export function StreamingIndicator() {
  return (
    <div className="flex items-center gap-1.5 px-4 py-2">
      <span className="text-xs text-slate-400 mr-1">NEXUS is thinking</span>
      <span className="w-2 h-2 rounded-full bg-nexus-accent animate-pulse-dot" style={{ animationDelay: '0ms' }} />
      <span className="w-2 h-2 rounded-full bg-nexus-primary animate-pulse-dot" style={{ animationDelay: '200ms' }} />
      <span className="w-2 h-2 rounded-full bg-nexus-cyan animate-pulse-dot" style={{ animationDelay: '400ms' }} />
    </div>
  );
}

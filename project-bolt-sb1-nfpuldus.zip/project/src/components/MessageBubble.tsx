import { useState } from 'react';
import { User, Bot, RefreshCw, ThumbsUp, ThumbsDown } from 'lucide-react';
import { Markdown } from './Markdown';
import { CopyButton } from './CopyButton';
import { useChat } from '@/context/ChatContext';
import type { ChatMessage } from '@/types';

interface Props {
  message: ChatMessage;
  isLast: boolean;
}

export function MessageBubble({ message, isLast }: Props) {
  const { regenerate, isStreaming, setFeedback } = useChat();
  const isUser = message.role === 'user';

  return (
    <div className={`flex gap-3 animate-slide-up ${isUser ? 'flex-row-reverse' : 'flex-row'}`}>
      <div
        className={`flex-shrink-0 w-8 h-8 rounded-lg flex items-center justify-center ${
          isUser
            ? 'bg-gradient-to-br from-nexus-cyan to-nexus-primary'
            : 'bg-gradient-to-br from-nexus-primary to-nexus-accent'
        }`}
      >
        {isUser ? <User className="w-4 h-4 text-white" /> : <Bot className="w-4 h-4 text-white" />}
      </div>

      <div className={`flex flex-col gap-1.5 max-w-[85%] ${isUser ? 'items-end' : 'items-start'}`}>
        <div
          className={`rounded-2xl px-4 py-3 ${
            isUser
              ? 'bg-gradient-to-br from-nexus-primary/20 to-nexus-accent/20 border border-nexus-primary/30 text-slate-100'
              : 'glass text-slate-100'
          }`}
        >
          {isUser ? (
            <p className="text-[0.95rem] leading-relaxed whitespace-pre-wrap">{message.content}</p>
          ) : (
            <Markdown content={message.content} />
          )}
        </div>

        {!isUser && (
          <div className="flex items-center gap-3 px-1">
            <CopyButton text={message.content} label="Copy" />
            {isLast && !isStreaming && (
              <button
                onClick={regenerate}
                className="inline-flex items-center gap-1 text-xs text-slate-400 hover:text-nexus-cyan transition"
                title="Regenerate"
              >
                <RefreshCw className="w-3.5 h-3.5" />
                Regenerate
              </button>
            )}
            <button
              onClick={() => message.id.startsWith('tmp') || message.id.startsWith('partial') ? null : setFeedback(message.id, 'like')}
              className={`transition ${
                message.feedback === 'like' ? 'text-emerald-400' : 'text-slate-400 hover:text-emerald-400'
              }`}
              title="Like"
              disabled={message.id.startsWith('tmp') || message.id.startsWith('partial')}
            >
              <ThumbsUp className="w-3.5 h-3.5" />
            </button>
            <button
              onClick={() => message.id.startsWith('tmp') || message.id.startsWith('partial') ? null : setFeedback(message.id, 'dislike')}
              className={`transition ${
                message.feedback === 'dislike' ? 'text-rose-400' : 'text-slate-400 hover:text-rose-400'
              }`}
              title="Dislike"
              disabled={message.id.startsWith('tmp') || message.id.startsWith('partial')}
            >
              <ThumbsDown className="w-3.5 h-3.5" />
            </button>
          </div>
        )}
      </div>
    </div>
  );
}

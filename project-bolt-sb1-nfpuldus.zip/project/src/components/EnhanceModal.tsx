import { useEffect, useState } from 'react';
import { Wand2, X, Check, Loader2, ArrowRight } from 'lucide-react';
import { enhancePrompt } from '@/lib/api';
import { useToast } from '@/context/ToastContext';
import { useChat } from '@/context/ChatContext';
import type { Tone } from '@/types';

interface Props {
  prompt: string;
  tone: Tone;
  onClose: () => void;
  onUse: (text: string) => void;
}

export function EnhanceModal({ prompt, tone, onClose, onUse }: Props) {
  const [loading, setLoading] = useState(false);
  const [enhanced, setEnhanced] = useState('');
  const [editing, setEditing] = useState(false);
  const { toast } = useToast();
  const { current } = useChat();

  const run = async () => {
    setLoading(true);
    setEnhanced('');
    try {
      const res = await enhancePrompt(prompt, tone);
      setEnhanced(res.enhanced);
    } catch (e) {
      toast(e instanceof Error ? e.message : 'Enhance failed.', 'error');
    } finally {
      setLoading(false);
    }
  };

  // Auto-run on mount
  useEffect(() => { run(); }, []);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm animate-fade-in p-4">
      <div className="glass nexus-shadow rounded-2xl p-6 w-full max-w-2xl max-h-[85vh] overflow-y-auto scrollbar-thin">
        <div className="flex items-center justify-between mb-5">
          <div className="flex items-center gap-2">
            <div className="p-2 rounded-lg bg-gradient-to-br from-nexus-primary to-nexus-accent">
              <Wand2 className="w-4 h-4 text-white" />
            </div>
            <h3 className="font-display font-semibold text-lg text-white">Smart Prompt Enhancer</h3>
          </div>
          <button onClick={onClose} className="text-slate-400 hover:text-white">
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="space-y-4">
          <div>
            <p className="text-xs uppercase tracking-wider text-slate-500 mb-2 font-medium">Original</p>
            <div className="rounded-xl bg-nexus-bg/60 border border-nexus-border p-4 text-sm text-slate-300">
              {prompt}
            </div>
          </div>

          <div className="flex justify-center">
            <ArrowRight className="w-5 h-5 text-nexus-accent animate-pulse" />
          </div>

          <div>
            <div className="flex items-center justify-between mb-2">
              <p className="text-xs uppercase tracking-wider text-slate-500 font-medium">Enhanced</p>
              {enhanced && (
                <button
                  onClick={() => setEditing((e) => !e)}
                  className="text-xs text-nexus-cyan hover:text-nexus-cyan/80"
                >
                  {editing ? 'Done editing' : 'Edit'}
                </button>
              )}
            </div>
            {loading ? (
              <div className="rounded-xl bg-nexus-bg/60 border border-nexus-border p-4 flex items-center gap-2 text-sm text-slate-400">
                <Loader2 className="w-4 h-4 animate-spin text-nexus-accent" />
                Enhancing your prompt...
              </div>
            ) : enhanced ? (
              editing ? (
                <textarea
                  value={enhanced}
                  onChange={(e) => setEnhanced(e.target.value)}
                  rows={6}
                  className="w-full rounded-xl bg-nexus-bg border border-nexus-accent p-4 text-sm text-white focus:outline-none resize-y"
                />
              ) : (
                <div className="rounded-xl bg-gradient-to-br from-nexus-accent/10 to-nexus-primary/10 border border-nexus-accent/30 p-4 text-sm text-slate-100 whitespace-pre-wrap">
                  {enhanced}
                </div>
              )
            ) : (
              <div className="rounded-xl bg-nexus-bg/40 border border-dashed border-nexus-border p-4 text-sm text-slate-500">
                Enhanced prompt will appear here.
              </div>
            )}
          </div>
        </div>

        <div className="flex justify-end gap-3 mt-6">
          <button onClick={onClose} className="px-4 py-2 rounded-lg text-sm text-slate-300 hover:bg-white/10 transition">
            Cancel
          </button>
          <button
            disabled={!enhanced || loading}
            onClick={() => onUse(enhanced)}
            className="inline-flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-medium text-white bg-gradient-to-r from-nexus-primary to-nexus-accent hover:opacity-90 disabled:opacity-40 transition"
          >
            <Check className="w-4 h-4" />
            Use Improved Prompt
          </button>
        </div>
        <div className="sr-only">{current?.id}</div>
      </div>
    </div>
  );
}

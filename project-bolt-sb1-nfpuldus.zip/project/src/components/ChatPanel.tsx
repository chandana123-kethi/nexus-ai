import { useEffect, useRef } from 'react';
import { useChat } from '@/context/ChatContext';
import { MessageBubble } from './MessageBubble';
import { StreamingIndicator } from './StreamingIndicator';
import { Markdown } from './Markdown';
import { Welcome } from './Welcome';
import { ChatInput } from './ChatInput';
import { ToneSelector } from './ToneSelector';
import { Bot } from 'lucide-react';

export function ChatPanel({ onPickWelcome }: { onPickWelcome: (p: string) => void }) {
  const { messages, isStreaming, streamingText, loadingMessages, current } = useChat();
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const el = scrollRef.current;
    if (el) el.scrollTop = el.scrollHeight;
  }, [messages, streamingText, isStreaming]);

  const hasMessages = messages.length > 0 || isStreaming || streamingText.length > 0;

  return (
    <div className="flex flex-col h-full bg-nexus-bg">
      <div className="flex items-center justify-between px-4 py-3 border-b border-nexus-border bg-nexus-surface/60 backdrop-blur-xl">
        <div className="min-w-0">
          <h2 className="font-display font-semibold text-sm text-slate-100 truncate">
            {current?.title ?? 'New Conversation'}
          </h2>
        </div>
        <ToneSelector compact />
      </div>

      <div ref={scrollRef} className="flex-1 overflow-y-auto scrollbar-thin">
        {!hasMessages && !loadingMessages && (
          <Welcome onPick={(p) => { onPickWelcome(p); }} />
        )}
        {loadingMessages && (
          <div className="max-w-3xl mx-auto p-6 space-y-4">
            {[0, 1, 2].map((i) => (
              <div key={i} className="space-y-2">
                <div className="skeleton h-4 w-1/3" />
                <div className="skeleton h-20 w-full" />
              </div>
            ))}
          </div>
        )}
        {hasMessages && (
          <div className="max-w-3xl mx-auto p-4 sm:p-6 space-y-6">
            {messages.map((m, i) => (
              <MessageBubble key={m.id} message={m} isLast={i === messages.length - 1 && !isStreaming} />
            ))}
            {isStreaming && streamingText.length === 0 && (
              <div className="flex gap-3 animate-slide-up">
                <div className="flex-shrink-0 w-8 h-8 rounded-lg bg-gradient-to-br from-nexus-primary to-nexus-accent flex items-center justify-center">
                  <Bot className="w-4 h-4 text-white" />
                </div>
                <div className="glass rounded-2xl">
                  <StreamingIndicator />
                </div>
              </div>
            )}
            {isStreaming && streamingText.length > 0 && (
              <div className="flex gap-3 animate-slide-up">
                <div className="flex-shrink-0 w-8 h-8 rounded-lg bg-gradient-to-br from-nexus-primary to-nexus-accent flex items-center justify-center">
                  <Bot className="w-4 h-4 text-white" />
                </div>
                <div className="glass rounded-2xl px-4 py-3 max-w-[85%]">
                  <Markdown content={streamingText} />
                  <span className="inline-block w-1.5 h-4 bg-nexus-accent animate-pulse ml-0.5 align-middle" />
                </div>
              </div>
            )}
          </div>
        )}
      </div>

      <ChatInput onEnhanceUse={() => {}} />
    </div>
  );
}

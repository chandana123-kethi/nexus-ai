import { Sparkles, Lightbulb, Code2, PenLine, Rocket } from 'lucide-react';

const SUGGESTIONS = [
  {
    icon: Lightbulb,
    title: 'Brainstorm ideas',
    prompt: 'Brainstorm five innovative product ideas for a sustainable consumer tech startup.',
  },
  {
    icon: Code2,
    title: 'Explain code',
    prompt: 'Explain how async/await works in JavaScript with a practical example.',
  },
  {
    icon: PenLine,
    title: 'Write content',
    prompt: 'Write a professional LinkedIn post about launching a new AI product.',
  },
  {
    icon: Rocket,
    title: 'Plan a project',
    prompt: 'Create a step-by-step launch plan for a mobile app going from beta to public release.',
  },
];

interface Props {
  onPick: (prompt: string) => void;
}

export function Welcome({ onPick }: Props) {
  return (
    <div className="flex flex-col items-center justify-center h-full px-6 py-12 text-center max-w-3xl mx-auto">
      <div className="relative mb-6">
        <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-nexus-primary to-nexus-accent flex items-center justify-center nexus-shadow">
          <Sparkles className="w-8 h-8 text-white" />
        </div>
        <div className="absolute inset-0 rounded-2xl bg-gradient-to-br from-nexus-cyan/40 to-transparent animate-glow" />
      </div>
      <h1 className="font-display font-bold text-3xl sm:text-4xl mb-3">
        <span className="gradient-text">Welcome to NEXUS AI</span>
      </h1>
      <p className="text-slate-400 text-base sm:text-lg mb-1">
        Your intelligent thinking workspace.
      </p>
      <p className="text-slate-500 text-sm mb-8 italic">Think Better. Create Faster.</p>

      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 w-full">
        {SUGGESTIONS.map((s) => {
          const Icon = s.icon;
          return (
            <button
              key={s.title}
              onClick={() => onPick(s.prompt)}
              className="group text-left p-4 rounded-xl glass hover:border-nexus-accent/40 transition-all hover:translate-y-[-2px]"
            >
              <div className="flex items-start gap-3">
                <div className="p-2 rounded-lg bg-nexus-bg/60 border border-nexus-border group-hover:border-nexus-accent/40 transition">
                  <Icon className="w-4 h-4 text-nexus-accent" />
                </div>
                <div>
                  <p className="font-medium text-sm text-slate-100 mb-0.5">{s.title}</p>
                  <p className="text-xs text-slate-400 line-clamp-2">{s.prompt}</p>
                </div>
              </div>
            </button>
          );
        })}
      </div>
    </div>
  );
}

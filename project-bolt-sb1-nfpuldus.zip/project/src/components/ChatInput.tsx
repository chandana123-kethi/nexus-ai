import { useEffect, useRef, useState } from 'react';
import { Send, Square, Wand2 } from 'lucide-react';
import { useChat } from '@/context/ChatContext';
import { EnhanceModal } from './EnhanceModal';

export function ChatInput({ onEnhanceUse }: { onEnhanceUse?: () => void }) {
  const { sendMessage, isStreaming, stopGeneration, current } = useChat();
  const [value, setValue] = useState('');
  const [showEnhance, setShowEnhance] = useState(false);
  const ref = useRef<HTMLTextAreaElement>(null);

  const autoResize = () => {
    const el = ref.current;
    if (!el) return;
    el.style.height = 'auto';
    el.style.height = `${Math.min(el.scrollHeight, 200)}px`;
  };

  useEffect(() => { autoResize(); }, [value]);

  const submit = () => {
    if (!value.trim() || isStreaming) return;
    sendMessage(value);
    setValue('');
  };

  const onKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      submit();
    }
  };

  return (
    <div className="px-4 pb-4 pt-2">
      <div className="max-w-3xl mx-auto">
        <div className="glass nexus-shadow rounded-2xl p-3">
          <textarea
            ref={ref}
            value={value}
            onChange={(e) => setValue(e.target.value)}
            onKeyDown={onKeyDown}
            rows={1}
            placeholder="Message NEXUS AI...  (Enter to send, Shift+Enter for new line)"
            className="w-full bg-transparent text-slate-100 placeholder-slate-500 text-sm resize-none focus:outline-none scrollbar-thin px-1 py-1"
          />
          <div className="flex items-center justify-between mt-2">
            <button
              onClick={() => setShowEnhance(true)}
              disabled={!value.trim() || isStreaming}
              className="inline-flex items-center gap-1.5 text-xs text-slate-400 hover:text-nexus-accent disabled:opacity-40 transition px-2 py-1.5 rounded-lg hover:bg-white/5"
              title="Improve this prompt with AI"
            >
              <Wand2 className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">Improve Prompt</span>
            </button>
            <div className="flex items-center gap-2">
              {isStreaming ? (
                <button
                  onClick={stopGeneration}
                  className="inline-flex items-center gap-1.5 px-3 py-2 rounded-lg bg-rose-500/90 text-white text-sm hover:bg-rose-500 transition"
                >
                  <Square className="w-3.5 h-3.5" />
                  Stop
                </button>
              ) : (
                <button
                  onClick={submit}
                  disabled={!value.trim()}
                  className="inline-flex items-center justify-center w-9 h-9 rounded-lg bg-gradient-to-br from-nexus-primary to-nexus-accent text-white hover:opacity-90 disabled:opacity-30 transition"
                  title="Send"
                >
                  <Send className="w-4 h-4" />
                </button>
              )}
            </div>
          </div>
        </div>
        <p className="text-center text-[11px] text-slate-600 mt-2">
          NEXUS AI can make mistakes. Verify important information.
        </p>
      </div>

      {showEnhance && (
        <EnhanceModal
          prompt={value}
          tone={current?.selectedTone ?? 'professional'}
          onClose={() => setShowEnhance(false)}
          onUse={(text) => {
            setValue(text);
            setShowEnhance(false);
            onEnhanceUse?.();
          }}
        />
      )}
    </div>
  );
}

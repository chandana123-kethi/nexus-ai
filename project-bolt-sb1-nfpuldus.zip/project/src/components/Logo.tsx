import { Sparkles } from 'lucide-react';

export function Logo({ size = 32 }: { size?: number }) {
  return (
    <div className="flex items-center gap-2.5 select-none">
      <div
        className="relative flex items-center justify-center rounded-xl bg-gradient-to-br from-nexus-primary to-nexus-accent nexus-shadow"
        style={{ width: size, height: size }}
      >
        <Sparkles className="text-white" style={{ width: size * 0.55, height: size * 0.55 }} />
        <div className="absolute inset-0 rounded-xl bg-gradient-to-br from-nexus-cyan/30 to-transparent animate-glow" />
      </div>
      <div className="leading-none">
        <span className="font-display font-bold text-lg tracking-tight gradient-text">NEXUS</span>
        <span className="font-display font-light text-lg text-slate-300 ml-1">AI</span>
      </div>
    </div>
  );
}

import { Briefcase, Coffee, Zap } from 'lucide-react';
import { useChat } from '@/context/ChatContext';
import type { Tone } from '@/types';

const TONES: { value: Tone; label: string; icon: typeof Briefcase; desc: string }[] = [
  { value: 'professional', label: 'Professional', icon: Briefcase, desc: 'Formal & structured' },
  { value: 'casual', label: 'Casual', icon: Coffee, desc: 'Friendly & natural' },
  { value: 'concise', label: 'Concise', icon: Zap, desc: 'Short & direct' },
];

export function ToneSelector({ compact = false }: { compact?: boolean }) {
  const { current, setTone } = useChat();
  const active = current?.selectedTone ?? 'professional';

  if (compact) {
    return (
      <div className="inline-flex items-center gap-1 bg-nexus-bg/60 border border-nexus-border rounded-lg p-1">
        {TONES.map((t) => {
          const Icon = t.icon;
          const isActive = active === t.value;
          return (
            <button
              key={t.value}
              onClick={() => setTone(t.value)}
              className={`flex items-center gap-1.5 px-2.5 py-1.5 rounded-md text-xs font-medium transition ${
                isActive
                  ? 'bg-gradient-to-r from-nexus-primary to-nexus-accent text-white'
                  : 'text-slate-400 hover:text-white hover:bg-white/5'
              }`}
              title={t.desc}
            >
              <Icon className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">{t.label}</span>
            </button>
          );
        })}
      </div>
    );
  }

  return (
    <div className="grid grid-cols-3 gap-2 w-full">
      {TONES.map((t) => {
        const Icon = t.icon;
        const isActive = active === t.value;
        return (
          <button
            key={t.value}
            onClick={() => setTone(t.value)}
            className={`flex flex-col items-center gap-1 px-3 py-3 rounded-xl border transition text-center ${
              isActive
                ? 'bg-gradient-to-br from-nexus-primary/20 to-nexus-accent/20 border-nexus-accent text-white'
                : 'bg-nexus-bg/40 border-nexus-border text-slate-400 hover:border-nexus-accent/40 hover:text-white'
            }`}
          >
            <Icon className="w-5 h-5" />
            <span className="text-xs font-medium">{t.label}</span>
          </button>
        );
      })}
    </div>
  );
}

import { useState } from 'react';
import {
  Search, Plus, MessageSquare, Pencil, Trash2, Check, X, Settings, Sun, Moon,
} from 'lucide-react';
import { useChat } from '@/context/ChatContext';
import { Logo } from './Logo';
import type { Theme } from '@/types';

interface Props {
  theme: Theme;
  onToggleTheme: () => void;
  onClose?: () => void;
}

export function Sidebar({ theme, onToggleTheme, onClose }: Props) {
  const {
    conversations, current, loadingConversations,
    selectConversation, newConversation, renameConversation, deleteConversation,
  } = useChat();
  const [query, setQuery] = useState('');
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editValue, setEditValue] = useState('');
  const [confirmId, setConfirmId] = useState<string | null>(null);

  const filtered = conversations.filter((c) =>
    c.title.toLowerCase().includes(query.toLowerCase()),
  );

  const startEdit = (id: string, title: string) => {
    setEditingId(id);
    setEditValue(title);
  };
  const commitEdit = async () => {
    if (editingId && editValue.trim()) {
      await renameConversation(editingId, editValue.trim());
    }
    setEditingId(null);
  };

  const handleNew = async () => {
    await newConversation();
    onClose?.();
  };

  const handleSelect = (id: string) => {
    selectConversation(id);
    onClose?.();
  };

  return (
    <div className="flex flex-col h-full bg-nexus-surface border-r border-nexus-border">
      <div className="p-4 flex items-center justify-between">
        <Logo size={30} />
        {onClose && (
          <button onClick={onClose} className="lg:hidden text-slate-400 hover:text-white">
            <X className="w-5 h-5" />
          </button>
        )}
      </div>

      <div className="px-3">
        <button
          onClick={handleNew}
          className="w-full flex items-center justify-center gap-2 py-2.5 rounded-xl bg-gradient-to-r from-nexus-primary to-nexus-accent text-white font-medium text-sm hover:opacity-90 transition nexus-shadow"
        >
          <Plus className="w-4 h-4" />
          New Chat
        </button>
      </div>

      <div className="px-3 mt-3">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500" />
          <input
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Search conversations..."
            className="w-full pl-9 pr-3 py-2 rounded-lg bg-nexus-bg/60 border border-nexus-border text-sm text-slate-200 placeholder-slate-500 focus:outline-none focus:border-nexus-accent/60 transition"
          />
        </div>
      </div>

      <div className="flex-1 overflow-y-auto scrollbar-thin px-2 mt-3 space-y-1">
        {loadingConversations && (
          <div className="space-y-2 px-2">
            {[0, 1, 2, 3].map((i) => (
              <div key={i} className="skeleton h-10 w-full" />
            ))}
          </div>
        )}
        {!loadingConversations && filtered.length === 0 && (
          <div className="px-3 py-8 text-center text-sm text-slate-500">
            <MessageSquare className="w-8 h-8 mx-auto mb-2 opacity-40" />
            No conversations yet.
          </div>
        )}
        {filtered.map((c) => (
          <div
            key={c.id}
            className={`group flex items-center gap-2 px-3 py-2 rounded-lg cursor-pointer transition ${
              current?.id === c.id
                ? 'bg-nexus-accent/15 border border-nexus-accent/30'
                : 'hover:bg-white/5 border border-transparent'
            }`}
            onClick={() => handleSelect(c.id)}
          >
            <MessageSquare className={`w-4 h-4 flex-shrink-0 ${current?.id === c.id ? 'text-nexus-accent' : 'text-slate-500'}`} />
            {editingId === c.id ? (
              <input
                autoFocus
                value={editValue}
                onChange={(e) => setEditValue(e.target.value)}
                onClick={(e) => e.stopPropagation()}
                onKeyDown={(e) => {
                  if (e.key === 'Enter') commitEdit();
                  if (e.key === 'Escape') setEditingId(null);
                }}
                className="flex-1 bg-nexus-bg border border-nexus-accent rounded px-2 py-0.5 text-sm text-white focus:outline-none"
              />
            ) : (
              <span className="flex-1 truncate text-sm text-slate-200">{c.title}</span>
            )}
            {editingId === c.id ? (
              <button onClick={(e) => { e.stopPropagation(); commitEdit(); }} className="text-emerald-400 hover:text-emerald-300">
                <Check className="w-4 h-4" />
              </button>
            ) : (
              <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition">
                <button
                  onClick={(e) => { e.stopPropagation(); startEdit(c.id, c.title); }}
                  className="text-slate-400 hover:text-nexus-cyan"
                  title="Rename"
                >
                  <Pencil className="w-3.5 h-3.5" />
                </button>
                <button
                  onClick={(e) => { e.stopPropagation(); setConfirmId(c.id); }}
                  className="text-slate-400 hover:text-rose-400"
                  title="Delete"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              </div>
            )}
          </div>
        ))}
      </div>

      <div className="p-3 border-t border-nexus-border space-y-2">
        <div className="flex items-center justify-between px-2">
          <button className="flex items-center gap-2 text-sm text-slate-300 hover:text-white transition">
            <Settings className="w-4 h-4" />
            Settings
          </button>
          <button
            onClick={onToggleTheme}
            className="flex items-center gap-2 text-sm text-slate-300 hover:text-white transition"
            title="Toggle theme"
          >
            {theme === 'dark' ? <Sun className="w-4 h-4" /> : <Moon className="w-4 h-4" />}
            {theme === 'dark' ? 'Light' : 'Dark'}
          </button>
        </div>
      </div>

      {confirmId && (
        <ConfirmDialog
          title="Delete conversation?"
          message="This will permanently remove the conversation and all its messages. This cannot be undone."
          confirmLabel="Delete"
          danger
          onConfirm={async () => {
            await deleteConversation(confirmId);
            setConfirmId(null);
          }}
          onCancel={() => setConfirmId(null)}
        />
      )}
    </div>
  );
}

function ConfirmDialog({
  title, message, confirmLabel, danger, onConfirm, onCancel,
}: {
  title: string; message: string; confirmLabel: string; danger?: boolean;
  onConfirm: () => void; onCancel: () => void;
}) {
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm animate-fade-in p-4">
      <div className="glass nexus-shadow rounded-2xl p-6 w-full max-w-sm">
        <h3 className="font-display font-semibold text-lg text-white mb-2">{title}</h3>
        <p className="text-sm text-slate-300 mb-5">{message}</p>
        <div className="flex justify-end gap-3">
          <button onClick={onCancel} className="px-4 py-2 rounded-lg text-sm text-slate-300 hover:bg-white/10 transition">
            Cancel
          </button>
          <button
            onClick={onConfirm}
            className={`px-4 py-2 rounded-lg text-sm font-medium text-white transition ${
              danger ? 'bg-rose-500 hover:bg-rose-600' : 'bg-nexus-primary hover:bg-nexus-primary/90'
            }`}
          >
            {confirmLabel}
          </button>
        </div>
      </div>
    </div>
  );
}

import { useEffect, useRef, useState } from 'react';
import { Check, Copy } from 'lucide-react';
import { useToast } from '@/context/ToastContext';

export function CopyButton({ text, label = 'Copy' }: { text: string; label?: string }) {
  const [copied, setCopied] = useState(false);
  const timer = useRef<ReturnType<typeof setTimeout> | null>(null);
  const { toast } = useToast();

  useEffect(() => () => { if (timer.current) clearTimeout(timer.current); }, []);

  const onCopy = async () => {
    try {
      await navigator.clipboard.writeText(text);
      setCopied(true);
      toast(`${label} copied.`, 'success');
      timer.current = setTimeout(() => setCopied(false), 1800);
    } catch {
      toast('Copy failed.', 'error');
    }
  };

  return (
    <button
      onClick={onCopy}
      className="inline-flex items-center gap-1 text-xs text-slate-400 hover:text-nexus-cyan transition"
      title={label}
    >
      {copied ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
      <span>{copied ? 'Copied' : label}</span>
    </button>
  );
}

# NEXUS AI — Intelligent Conversational Workspace

**Think Better. Create Faster.**

NEXUS AI is a premium, full-featured AI chat assistant with real-time streaming responses, conversation intelligence, and a polished glassmorphism interface.

![NEXUS AI](https://bolt.new/static/og_default.png)

---

## Features

### Core Chat
- **Real AI conversations** powered by OpenAI (GPT-4o-mini)
- **Server-Sent Events (SSE) streaming** — responses appear progressively, token by token (no simulated timeouts)
- **Continuous context** — previous messages are sent as conversation history
- **Stop generation** mid-stream
- **Regenerate** the last AI response
- **Copy** any response or code block
- **Like / Dislike** feedback on assistant messages
- **Markdown rendering** with syntax-highlighted code blocks
- **Multiline input** (Shift+Enter for new line, Enter to send)

### Tone Toggle
Three selectable response styles that change the AI's output:
- **Professional** — formal, structured, business-oriented
- **Casual** — friendly, natural, conversational
- **Concise** — short, direct, easy to understand

The selected tone is converted to a system instruction on the backend and passed to OpenAI on every request.

### Smart Prompt Enhancer
- Click **Improve Prompt** beside the input
- AI rewrites your prompt for clarity, context, and structure
- Compare original vs enhanced side-by-side
- Edit the enhanced version before using it
- **You decide** whether to use it — nothing is sent automatically

### Conversation Intelligence (Right Panel)
For each conversation, NEXUS AI generates:
- **Summary** — concise overview of the discussion
- **Key Takeaways** — most important information
- **Decisions** — explicit conclusions reached
- **Action Items** — tasks and next steps identified

Insights are generated from real conversation content using structured JSON output, saved to the database, and can be refreshed on demand. The AI is instructed to never invent decisions or action items.

### Conversation Management
- Create, rename, and delete conversations
- Searchable conversation history (persists after refresh)
- Auto-generated titles based on the first user message
- Delete confirmation dialog

### UI / UX
- Dark navy theme with electric-blue/purple gradients and glassmorphism
- **Dark mode and Light mode** with theme toggle
- Fully responsive (desktop, tablet, mobile) with mobile drawer navigation
- Toast notifications, loading skeletons, empty states
- Smooth animations and micro-interactions
- Keyboard shortcuts: `Ctrl/Cmd+K` (sidebar), `Ctrl/Cmd+I` (intelligence panel)

---

## Technology Stack

| Layer | Technology |
|-------|-----------|
| Frontend | React 18, TypeScript, Tailwind CSS, Lucide React |
| Markdown | react-markdown, remark-gfm, rehype-highlight |
| Backend | Supabase Edge Functions (Deno runtime) |
| Database | Supabase Postgres with Row Level Security |
| AI | OpenAI API (GPT-4o-mini) |
| Streaming | Server-Sent Events (SSE) |

> **Note:** The original spec requested Node.js/Express + MongoDB. This Bolt environment uses Supabase (Postgres + Edge Functions) as its managed backend, so the architecture was adapted to that stack while preserving every feature — real AI streaming, tone selection, prompt enhancement, conversation intelligence, and persistent history.

---

## Project Architecture

```
nexus-ai/
├── src/                          # Frontend
│   ├── components/               # UI components
│   │   ├── ChatInput.tsx         # Message input + tone + enhance button
│   │   ├── ChatPanel.tsx         # Center chat interface
│   │   ├── CopyButton.tsx        # Reusable copy-to-clipboard
│   │   ├── EnhanceModal.tsx      # Smart Prompt Enhancer UI
│   │   ├── IntelligencePanel.tsx # Right panel — insights
│   │   ├── Logo.tsx              # NEXUS AI branding
│   │   ├── Markdown.tsx          # Markdown + code highlighting
│   │   ├── MessageBubble.tsx     # User/assistant message bubbles
│   │   ├── Sidebar.tsx           # Conversation list + search + theme
│   │   ├── StreamingIndicator.tsx
│   │   ├── ToneSelector.tsx      # Professional / Casual / Concise
│   │   └── Welcome.tsx           # Welcome screen + suggested prompts
│   ├── context/
│   │   ├── ChatContext.tsx       # Conversations, messages, streaming state
│   │   └── ToastContext.tsx      # Toast notifications
│   ├── hooks/
│   │   └── useTheme.ts           # Dark/light theme management
│   ├── lib/
│   │   ├── api.ts                # REST + SSE client for backend
│   │   └── supabase.ts           # Supabase client singleton
│   └── types/
│       └── index.ts              # Shared TypeScript types
├── supabase/
│   ├── config.toml               # Edge function config
│   ├── functions/
│   │   └── nexus-ai/
│   │       └── index.ts          # All backend logic (stream, enhance, insights, feedback)
│   └── migrations/
│       └── ...create_conversations_schema.sql
└── .env.example
```

### Backend (Edge Function)

A single Edge Function `nexus-ai` handles all server-side logic via an `?action=` query parameter:

| Action | Method | Description |
|--------|--------|-------------|
| `stream` | POST | Streams AI chat response via SSE, persists user + assistant messages |
| `enhance` | POST | Improves a prompt using AI, returns enhanced version |
| `insights` | POST | Generates conversation summary/takeaways/decisions/actions as JSON, saves to DB |
| `feedback` | POST | Records like/dislike on a message |

The function reads the `OPENAI_API_KEY` secret server-side — the key is never exposed to the frontend.

### Database Schema

Three tables (all with RLS enabled):

- **conversations** — `id`, `title`, `selected_tone`, `created_at`, `updated_at`
- **messages** — `id`, `conversation_id` (FK, cascade delete), `role`, `content`, `tone`, `feedback`, `created_at`
- **insights** — `id`, `conversation_id` (FK, unique), `summary`, `key_takeaways` (jsonb), `decisions` (jsonb), `action_items` (jsonb), timestamps

Single-tenant (no auth): policies grant CRUD to `anon, authenticated`.

---

## Installation & Setup

### Prerequisites
- Node.js 18+
- An OpenAI API key ([get one here](https://platform.openai.com/api-keys))

### 1. Install dependencies

```bash
npm install
```

### 2. Configure environment

The Supabase URL and anon key are pre-configured by Bolt in `.env`. You only need to add the OpenAI key:

**In Bolt:** Click the **Database icon** → **Secrets** → add `OPENAI_API_KEY` with your key value.

**Or in Supabase Dashboard:** Edge Functions → Secrets → add `OPENAI_API_KEY`.

### 3. Run the development server

```bash
npm run dev
```

The app opens at the Vite dev URL.

### 4. Build for production

```bash
npm run build
```

---

## API Documentation

### `POST /functions/v1/nexus-ai?action=stream`
Stream a chat response. Body: `{ conversationId, message, tone }`. Returns `text/event-stream` with `data: {"delta":"..."}` chunks, terminated by `data: [DONE]`.

### `POST /functions/v1/nexus-ai?action=enhance`
Enhance a prompt. Body: `{ prompt, tone }`. Returns `{ original, enhanced }`.

### `POST /functions/v1/nexus-ai?action=insights`
Generate conversation insights. Body: `{ conversationId }`. Returns `{ summary, key_takeaways, decisions, action_items, empty }`.

### `POST /functions/v1/nexus-ai?action=feedback`
Record message feedback. Body: `{ messageId, feedback }` where feedback is `"like"` or `"dislike"`.

### REST API (Supabase Data API)
Standard PostgREST endpoints for `conversations`, `messages`, and `insights` tables (filtered by query params, authenticated with the anon key).

---

## Security

- OpenAI API key stored only as a backend secret — never in frontend code
- Centralized error handling in the edge function with proper HTTP status codes
- Rate-limit and API-error handling with user-friendly messages
- Row Level Security enabled on all database tables
- CORS headers on every edge function response

---

## License

MIT
